import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const WeightDiaryApp());

class WeightEntry {
  final String date;
  final double kg;
  WeightEntry(this.date, this.kg);
  Map<String, dynamic> toJson() => {'date': date, 'kg': kg};
  factory WeightEntry.fromJson(Map<String, dynamic> json) =>
      WeightEntry(json['date'] as String, (json['kg'] as num).toDouble());
}

class WeightDiaryApp extends StatefulWidget {
  const WeightDiaryApp({super.key});
  @override
  State<WeightDiaryApp> createState() => _WeightDiaryAppState();
}

class _WeightDiaryAppState extends State<WeightDiaryApp> {
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();
  String language = 'ru';
  double? heightCm;
  double? targetKg;
  List<WeightEntry> entries = [];
  bool loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('entries') ?? '[]';
    final decoded = (jsonDecode(raw) as List)
        .map((e) => WeightEntry.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    setState(() {
      entries = decoded..sort((a, b) => a.date.compareTo(b.date));
      language = p.getString('language') ?? 'ru';
      heightCm = p.getDouble('heightCm');
      targetKg = p.getDouble('targetKg');
      loaded = true;
    });
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('entries', jsonEncode(entries.map((e) => e.toJson()).toList()));
    await p.setString('language', language);
    if (heightCm != null) await p.setDouble('heightCm', heightCm!);
    if (targetKg != null) await p.setDouble('targetKg', targetKg!);
  }

  String t(String ru, String kk) => language == 'ru' ? ru : kk;
  double? get current => entries.isEmpty ? null : entries.last.kg;
  double? get bmi => (current != null && heightCm != null && heightCm! > 0)
      ? current! / ((heightCm! / 100) * (heightCm! / 100)) : null;

  Future<void> _addWeight(BuildContext dialogContext) async {
    final controller = TextEditingController(text: current?.toString() ?? '');
    final result = await showDialog<double>(
      context: dialogContext,
      builder: (ctx) => AlertDialog(
        title: Text(t('Записать вес', 'Салмақты жазу')),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(
            labelText: t('Вес в кг', 'Салмақ, кг'),
            hintText: '72,5',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(t('Отмена', 'Бас тарту'))),
          FilledButton(
            onPressed: () {
              final v = double.tryParse(controller.text.trim().replaceAll(',', '.'));
              if (v != null && v >= 20 && v <= 400) Navigator.pop(ctx, v);
            },
            child: Text(t('Сохранить', 'Сақтау')),
          ),
        ],
      ),
    );
    if (result == null) return;
    final now = DateTime.now();
    final date = '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    setState(() {
      final i = entries.indexWhere((e) => e.date == date);
      if (i >= 0) {
        entries[i] = WeightEntry(date, result);
      } else {
        entries.add(WeightEntry(date, result));
        entries.sort((a, b) => a.date.compareTo(b.date));
      }
    });
    await _save();
  }

  Future<void> _editProfile(BuildContext dialogContext) async {
    final h = TextEditingController(text: heightCm?.toString() ?? '');
    final goal = TextEditingController(text: targetKg?.toString() ?? '');
    final ok = await showDialog<bool>(
      context: dialogContext,
      builder: (ctx) => AlertDialog(
        title: Text(t('Мои цели', 'Менің мақсаттарым')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: h, keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: t('Рост, см', 'Бойы, см'))),
          TextField(controller: goal, keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: t('Желаемый вес, кг', 'Мақсатты салмақ, кг'))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(t('Отмена', 'Бас тарту'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(t('Сохранить', 'Сақтау'))),
        ],
      ),
    );
    if (ok == true) {
      setState(() {
        heightCm = double.tryParse(h.text.replaceAll(',', '.'));
        targetKg = double.tryParse(goal.text.replaceAll(',', '.'));
      });
      await _save();
    }
  }

  @override
  Widget build(BuildContext context) {
    const pink = Color(0xFFB34DDB);
    return MaterialApp(
      navigatorKey: _navigatorKey,
      debugShowCheckedModeBanner: false,
      title: 'Мой вес',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(seedColor: pink, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF8F4FF),
        cardTheme: CardThemeData(color: Colors.white, elevation: 2,
          shadowColor: const Color(0x1AB34DDB),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22))),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      home: loaded ? Builder(builder: (homeContext) => _home(homeContext)) : const Scaffold(body: Center(child: CircularProgressIndicator())),
    );
  }

  Widget _home(BuildContext homeContext) {
    final currentText = current == null ? '—' : current!.toStringAsFixed(1);
    final remaining = (current != null && targetKg != null) ? (current! - targetKg!).abs() : null;
    final progress = (current != null && targetKg != null && entries.length > 1)
        ? ((entries.first.kg - current!) / (entries.first.kg - targetKg! == 0 ? 1 : entries.first.kg - targetKg!)).clamp(0.0, 1.0)
        : 0.0;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFF8F4FF),
        surfaceTintColor: Colors.transparent,
        title: const Text('Мой вес', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          TextButton(
            onPressed: () async {
              setState(() => language = language == 'ru' ? 'kk' : 'ru');
              await _save();
            },
            child: Text(language == 'ru' ? 'ҚАЗ' : 'РУС'),
          ),
          IconButton(onPressed: () => _editProfile(homeContext), icon: const Icon(Icons.tune_rounded)),
        ],
      ),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
        Text(t('Твой путь к комфортному весу', 'Қолайлы салмаққа жолың'),
          style: const TextStyle(color: Color(0xFF796487))),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: _metric(t('Текущий вес', 'Қазіргі салмақ'), '$currentText кг', Icons.monitor_weight_outlined)),
          const SizedBox(width: 12),
          Expanded(child: _metric(t('Цель', 'Мақсат'), targetKg == null ? '—' : '${targetKg!.toStringAsFixed(1)} кг', Icons.flag_outlined)),
        ]),
        const SizedBox(height: 14),
        Card(child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t('Мой прогресс', 'Менің жетістігім'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
            const SizedBox(height: 10),
            LinearProgressIndicator(value: progress, minHeight: 9,
              borderRadius: BorderRadius.circular(20), color: const Color(0xFFB34DDB),
              backgroundColor: const Color(0xFFEADCF7)),
            const SizedBox(height: 8),
            Text(remaining == null ? t('Укажи желаемый вес в настройках', 'Баптауларда мақсатты салмақты енгіз') :
              t('Разница до цели: ${remaining.toStringAsFixed(1)} кг', 'Мақсатқа дейін: ${remaining.toStringAsFixed(1)} кг'),
              style: const TextStyle(color: Color(0xFF796487), fontSize: 13)),
          ]),
        )),
        const SizedBox(height: 14),
        SizedBox(height: 54, child: FilledButton.icon(
          onPressed: () => _addWeight(homeContext),
          icon: const Icon(Icons.add_circle_outline),
          label: Text(t('Записать сегодняшний вес', 'Бүгінгі салмақты жазу')),
          style: FilledButton.styleFrom(backgroundColor: const Color(0xFFB34DDB),
            foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
        )),
        const SizedBox(height: 14),
        Card(child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t('Изменение веса', 'Салмақ өзгерісі'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
            const SizedBox(height: 14),
            SizedBox(height: 130, child: entries.length < 2
              ? Center(child: Text(t('Добавь минимум две записи, чтобы увидеть график', 'Графикті көру үшін кемінде екі жазба қос'), textAlign: TextAlign.center,
                style: const TextStyle(color: Color(0xFF897A98))))
              : CustomPaint(painter: WeightChart(entries.map((e) => e.kg).toList()), child: const SizedBox.expand())),
          ]),
        )),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(child: _metric('ИМТ', bmi == null ? '—' : bmi!.toStringAsFixed(1), Icons.calculate_outlined)),
          const SizedBox(width: 12),
          Expanded(child: _metric(t('Записей', 'Жазбалар'), '${entries.length}', Icons.calendar_month_outlined)),
        ]),
        const SizedBox(height: 14),
        Card(child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t('История', 'Тарих'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
            const SizedBox(height: 8),
            if (entries.isEmpty) Text(t('Пока нет записей. Добавь первый вес!', 'Әзірге жазба жоқ. Алғашқы салмақты енгіз!')),
            ...entries.reversed.take(8).map((e) => ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const CircleAvatar(backgroundColor: Color(0xFFF0E3FA), child: Icon(Icons.favorite, color: Color(0xFFB34DDB), size: 18)),
              title: Text('${e.kg.toStringAsFixed(1)} кг', style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(e.date),
              trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async {
                setState(() => entries.remove(e)); await _save();
              }),
            )),
          ]),
        )),
        const SizedBox(height: 12),
        // Advertising placeholder: replace with a compliant Google Mobile Ads banner
        // after creating an AdMob account and adding your own ad unit ID.
        Container(height: 54, alignment: Alignment.center,
          decoration: BoxDecoration(color: const Color(0xFFEFE3FA), borderRadius: BorderRadius.circular(14)),
          child: Text(t('Место для рекламы', 'Жарнама орны'),
            style: const TextStyle(color: Color(0xFF795A91), fontSize: 12))),
        const SizedBox(height: 10),
        Text(t('Подсказка: взвешивайся в одинаковых условиях. ИМТ — ориентир, а не диагноз.',
          'Кеңес: бірдей жағдайда өлшен. ДСИ — бағдар ғана, диагноз емес.'),
          textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: Color(0xFF897A98))),
      ]),
    );
  }

  Widget _metric(String label, String value, IconData icon) => Card(
    child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: const Color(0xFFB34DDB)),
      const SizedBox(height: 10),
      Text(label, style: const TextStyle(fontSize: 12, color: Color(0xFF796487))),
      const SizedBox(height: 3),
      Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
    ])),
  );
}

class WeightChart extends CustomPainter {
  final List<double> values;
  WeightChart(this.values);
  @override
  void paint(Canvas canvas, Size size) {
    if (values.length < 2) return;
    final minV = values.reduce((a,b) => a < b ? a : b) - 1;
    final maxV = values.reduce((a,b) => a > b ? a : b) + 1;
    final range = (maxV - minV).abs() < 0.01 ? 1.0 : maxV - minV;
    final points = <Offset>[];
    for (var i = 0; i < values.length; i++) {
      final x = 8 + (size.width - 16) * i / (values.length - 1);
      final y = size.height - 12 - ((values[i] - minV) / range) * (size.height - 24);
      points.add(Offset(x, y));
    }
    final line = Paint()..color = const Color(0xFFB34DDB)..strokeWidth = 3..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
    final path = Path()..moveTo(points.first.dx, points.first.dy);
    for (final p in points.skip(1)) { path.lineTo(p.dx, p.dy); }
    canvas.drawPath(path, line);
    final dot = Paint()..color = const Color(0xFFB34DDB);
    for (final p in points) { canvas.drawCircle(p, 4, dot); }
  }
  @override
  bool shouldRepaint(covariant WeightChart oldDelegate) => oldDelegate.values != values;
}
